export declare const StyledWrapper: any;
export declare const StyledText: any;
export declare const StyledRemove: any;
export declare const StyledTHSite: any;
export declare const StyledTHOther: any;
export declare const StyledTHLast: any;
export declare const StyledToggle: any;
