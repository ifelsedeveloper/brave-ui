export declare const StyledWrapper: any;
export declare const StyledArea: any;
