declare const StyledSelectOption: any;
declare const StyledSelectOptionWrapper: any;
declare const StyledSelectOptionTitle: any;
export { StyledSelectOption, StyledSelectOptionWrapper, StyledSelectOptionTitle };
