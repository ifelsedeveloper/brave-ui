declare const StyledPicture: any;
declare const StyledFigure: any;
declare const StyledFigcaption: any;
declare const StyledImage: any;
export { StyledPicture, StyledFigure, StyledFigcaption, StyledImage };
