"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
module.exports =
    React.createElement("svg", { width: '8', height: '5', xmlns: 'http://www.w3.org/2000/svg' },
        React.createElement("path", { d: 'M4 0a.558.558 0 0 0-.396.164l-3.44 3.44a.56.56 0 1 0 .793.792L4 1.353l3.044 3.043a.56.56 0 0 0 .792-.792L4.396.164A.557.557 0 0 0 4 0z', fill: '#FFF', fillRule: 'evenodd', fillOpacity: '0.55' }));
//# sourceMappingURL=arrowUp.js.map