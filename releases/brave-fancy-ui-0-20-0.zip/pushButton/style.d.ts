declare const StyledPushButton: any;
export default StyledPushButton;
