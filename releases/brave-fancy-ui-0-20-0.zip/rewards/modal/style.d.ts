export declare const StyledWrapper: any;
export declare const StyledDialog: any;
export declare const StyledClose: any;
export declare const StyledContent: any;
