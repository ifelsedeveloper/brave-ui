declare const StyledContentToggleArrow: any;
declare const StyledContentToggleArrowControl: any;
declare const StyledContentToggleArrowSummary: any;
declare const StyledContentToggleArrowContent: any;
export { StyledContentToggleArrow, StyledContentToggleArrowControl, StyledContentToggleArrowSummary, StyledContentToggleArrowContent };
