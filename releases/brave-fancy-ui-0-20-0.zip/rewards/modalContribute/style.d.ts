export declare const StyledWrapper: any;
export declare const StyledTitle: any;
export declare const StyledContent: any;
export declare const StyledNum: any;
