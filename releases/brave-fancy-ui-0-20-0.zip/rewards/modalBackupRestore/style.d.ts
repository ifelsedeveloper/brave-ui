export declare const StyledWrapper: any;
export declare const StyledContent: any;
export declare const StyledImport: any;
export declare const StyleButtonWrapper: any;
export declare const StyledDoneWrapper: any;
export declare const StyledActionsWrapper: any;
