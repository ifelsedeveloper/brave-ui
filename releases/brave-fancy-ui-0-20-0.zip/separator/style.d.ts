declare const StyledSeparator: any;
export default StyledSeparator;
