declare const StyledParagraph: any;
export default StyledParagraph;
