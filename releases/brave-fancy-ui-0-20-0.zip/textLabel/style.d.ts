declare const StyledTextLabel: any;
export default StyledTextLabel;
