declare const StyledPage: any;
declare const StyledPageContent: any;
export { StyledPage, StyledPageContent };
