declare const StyledPushButton: any;
declare const StyledPushButtonLink: any;
export { StyledPushButton, StyledPushButtonLink };
