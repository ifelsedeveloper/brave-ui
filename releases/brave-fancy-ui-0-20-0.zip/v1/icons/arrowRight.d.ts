import * as React from 'react';
declare class ArrowRight extends React.PureComponent {
    render(): JSX.Element;
}
export default ArrowRight;
