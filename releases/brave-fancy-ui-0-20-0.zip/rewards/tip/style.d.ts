export declare const StyledWrapper: any;
export declare const StyledTitle: any;
export declare const StyledAllow: any;
export declare const StyledAllowToggle: any;
export declare const StyledAllowText: any;
export declare const StyledClose: any;
