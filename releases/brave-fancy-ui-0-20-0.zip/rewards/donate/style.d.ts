export declare const StyledWrapper: any;
export declare const StyledContent: any;
export declare const StyledDonationTitle: any;
export declare const StyledSend: any;
export declare const StyledIconSend: any;
export declare const StyledFunds: any;
export declare const StyledIconFace: any;
export declare const StyledFundsText: any;
