import * as React from 'react';
interface Props {
    id?: string;
}
export default class PanelOff extends React.PureComponent<Props, {}> {
    render(): JSX.Element;
}
export {};
