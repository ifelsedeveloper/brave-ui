"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
module.exports =
    React.createElement("svg", { width: '50', height: '48', xmlns: 'http://www.w3.org/2000/svg' },
        React.createElement("g", { fill: 'none', fillRule: 'evenodd' },
            React.createElement("path", { fill: '#373743', opacity: '0.2', d: 'M37.55 47.795l12.43.03-5.238-9.696-44.68.06z' }),
            React.createElement("path", { fill: '#9E1F63', d: 'M24.01 0L24 26.054 47 39z' }),
            React.createElement("path", { fill: '#FB542B', d: 'M0 39l22.978-12.909L23 0z' }),
            React.createElement("path", { fill: '#662D91', d: 'M1 39l44-.002L23.044 27z' }),
            React.createElement("path", { fill: '#FFF', d: 'M23.426 16L14 31h19z' }),
            React.createElement("path", { stroke: '#999EA2', strokeWidth: '0.88', d: 'M23.426 16L14 31h19z' })));
//# sourceMappingURL=bat.js.map