export declare const StyledWrapper: any;
export declare const StyledNoContent: any;
export declare const StyledTable: any;
export declare const StyledTH: any;
export declare const StyledTR: any;
export declare const StyledTD: any;
