export declare const StyledWrapper: any;
export declare const StyledImage: any;
export declare const StyledContent: any;
