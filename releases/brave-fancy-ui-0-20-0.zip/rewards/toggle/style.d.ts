export declare const StyledWrapper: any;
export declare const StyledSlider: any;
export declare const StyledBullet: any;
