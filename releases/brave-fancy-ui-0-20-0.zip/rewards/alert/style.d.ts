export declare const StyledWrapper: any;
export declare const StyledIcon: any;
export declare const StyledContent: any;
export declare const StyledClose: any;
