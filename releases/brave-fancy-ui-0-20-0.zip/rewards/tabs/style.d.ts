export declare const StyledWrapper: any;
export declare const StyledTabWrapper: any;
export declare const StyledTab: any;
export declare const StyledContent: any;
