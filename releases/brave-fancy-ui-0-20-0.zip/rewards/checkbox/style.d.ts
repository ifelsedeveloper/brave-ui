export declare const StyledWrapper: any;
export declare const StyledLabel: any;
export declare const StyledBox: any;
export declare const StyledText: any;
