declare const StyledBoxedContent: any;
export default StyledBoxedContent;
