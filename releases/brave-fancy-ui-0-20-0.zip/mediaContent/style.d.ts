declare const StyledMediaContent: any;
declare const StyledMedia: any;
declare const StyledMediaBody: any;
export { StyledMediaContent, StyledMedia, StyledMediaBody };
