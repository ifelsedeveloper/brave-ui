export declare const StyledTokens: any;
export declare const StyledTokenValue: any;
export declare const StyledContent: any;
