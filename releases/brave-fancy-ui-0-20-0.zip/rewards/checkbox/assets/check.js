"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
module.exports =
    React.createElement("svg", { width: '9', height: '7', xmlns: 'http://www.w3.org/2000/svg' },
        React.createElement("path", { d: 'M.278 3.166l1.14-1.164 2.156 2.04L7.429-.005l1.21 1.172-5.065 5.17z', fill: '#696FDC', fillRule: 'evenodd' }));
//# sourceMappingURL=check.js.map