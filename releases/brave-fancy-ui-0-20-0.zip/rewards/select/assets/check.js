"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
module.exports =
    React.createElement("svg", { width: '12', height: '9', xmlns: 'http://www.w3.org/2000/svg' },
        React.createElement("path", { d: 'M0 4.227l1.519-1.551 2.875 2.72L9.534 0l1.614 1.563-1.424 1.453-5.33 5.439z', fill: '#A1A8F2', fillRule: 'evenodd' }));
//# sourceMappingURL=check.js.map