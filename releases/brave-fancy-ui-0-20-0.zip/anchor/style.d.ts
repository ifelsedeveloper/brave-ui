declare const StyledAnchor: any;
export default StyledAnchor;
