declare const StyledPanel: any;
export default StyledPanel;
