export declare const StyledWrapper: any;
export declare const StyledAmount: any;
export declare const StyledTokens: any;
export declare const StyledLogo: any;
export declare const StyledConverted: any;
