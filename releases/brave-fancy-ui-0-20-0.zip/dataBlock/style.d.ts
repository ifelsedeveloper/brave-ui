declare const StyledDataBlock: any;
declare const StyledDataItem: any;
declare const StyledDataItemCounter: any;
declare const StyledDataItemText: any;
declare const StyledDataItemDescription: any;
export { StyledDataBlock, StyledDataItem, StyledDataItemCounter, StyledDataItemText, StyledDataItemDescription };
