export declare const StyledWrapper: any;
export declare const StyledRemove: any;
export declare const StyledRemoveIcon: any;
export declare const StyledType: any;
export declare const StyledDate: any;
export declare const StyledToggle: any;
export declare const StyledRecurringIcon: any;
