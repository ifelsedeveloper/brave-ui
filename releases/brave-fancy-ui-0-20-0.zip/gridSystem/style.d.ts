declare const StyledGrid: any;
declare const StyledColumn: any;
export { StyledGrid, StyledColumn };
