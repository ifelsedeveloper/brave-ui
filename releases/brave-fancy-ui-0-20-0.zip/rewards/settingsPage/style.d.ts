export declare const StyledWrapper: any;
export declare const StyleHeader: any;
export declare const StyledContent: any;
