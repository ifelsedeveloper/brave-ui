import * as React from 'react';
interface Props {
    id?: string;
}
export default class PanelEmpty extends React.PureComponent<Props, {}> {
    render(): JSX.Element;
}
export {};
