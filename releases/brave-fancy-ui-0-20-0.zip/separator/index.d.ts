import * as React from 'react';
export interface SeparatorProps {
    noMargin?: boolean;
}
declare class Separator extends React.PureComponent<SeparatorProps, {}> {
    render(): JSX.Element;
}
export default Separator;
