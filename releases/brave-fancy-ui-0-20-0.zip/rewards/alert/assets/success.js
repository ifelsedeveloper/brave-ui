"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
module.exports =
    React.createElement("svg", { width: '42', height: '42', xmlns: 'http://www.w3.org/2000/svg' },
        React.createElement("g", { transform: 'translate(1 1)', fill: 'none', fillRule: 'evenodd' },
            React.createElement("path", { fill: '#1BBA6A', d: 'M13 21.045l1.6-1.48 3.166 2.848h1.483L27.48 15l1.49 1.39-9.72 10.117h-.69z' }),
            React.createElement("circle", { stroke: '#67D79D', cx: '20', cy: '20', r: '20' })));
//# sourceMappingURL=success.js.map