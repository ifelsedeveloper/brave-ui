"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
module.exports =
    React.createElement("svg", { width: '8', height: '5', xmlns: 'http://www.w3.org/2000/svg' },
        React.createElement("path", { d: 'M4 4.56a.558.558 0 0 1-.396-.164L.164.956A.56.56 0 1 1 .957.164L4 3.207 7.044.164a.56.56 0 0 1 .792.792l-3.44 3.44A.557.557 0 0 1 4 4.56z', fill: '#FFF', fillRule: 'evenodd', fillOpacity: '0.55' }));
//# sourceMappingURL=arrowDown.js.map