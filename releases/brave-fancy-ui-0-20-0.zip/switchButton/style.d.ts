declare const StyledSwitchButtonWrapper: any;
declare const StyledSwitchButtonLabel: any;
declare const StyledSwitchButton: any;
export { StyledSwitchButtonWrapper, StyledSwitchButtonLabel, StyledSwitchButton };
