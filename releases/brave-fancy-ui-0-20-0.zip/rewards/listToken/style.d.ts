export declare const StyledWrapper: any;
export declare const StyledTitle: any;
export declare const StyledContentWrapper: any;
