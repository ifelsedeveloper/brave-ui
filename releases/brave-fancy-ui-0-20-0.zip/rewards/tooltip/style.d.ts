export declare const StyledWrapper: any;
export declare const StyledArrow: any;
export declare const StyledArrowOutline: any;
export declare const StyledTooltip: any;
