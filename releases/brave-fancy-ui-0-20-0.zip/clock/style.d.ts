declare const StyledClock: any;
declare const StyledTime: any;
declare const StyledPeriod: any;
declare const StyledTimeSeparator: any;
export { StyledClock, StyledTime, StyledPeriod, StyledTimeSeparator };
