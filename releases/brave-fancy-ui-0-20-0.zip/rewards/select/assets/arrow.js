"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
module.exports =
    React.createElement("svg", { width: '11', height: '6', xmlns: 'http://www.w3.org/2000/svg' },
        React.createElement("path", { d: 'M0 0h2.165l2.837 3.625h.92L8.755 0h2.285L6.283 5.958H4.759z', fill: '#B8B9C4', fillRule: 'evenodd' }));
//# sourceMappingURL=arrow.js.map