declare const StyledUnstyledButton: any;
export default StyledUnstyledButton;
